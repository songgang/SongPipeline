sub10.png: emphysema patient
sub10_wmask.png: emphysema mask using -950HU as threshold
sub10_3d.png: 3d rendering of the emphysema region in the whole lung
sub10 whole aerated region volume: 3.602*10^6 mm^3
sub10 segmented emphysema (<-950) volume: 1.118*10^6 mm^3, 31.04%

a control example:
sub15:png: patient without emphysema
sub10 whole aerated region volume: 1.363*10^6 mm^3
sub10 segmented emphysema (<-950) volume:  423.539 mm^3  0.03% (possible segmentation error including airways)

